clear all
close all
clc
set(0,'defaulttextinterpreter','latex')

%lambda
lambda = '1.06';
PLOT_ALL=0;

%%% copy (in terminal)
% for lambda in {1.04,1.06,1.08}
% do
% for combi in {0..3}
% do
%     scp tyche:/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini30b417/lambda_sweep/theta_$lambda/stage/calc_data_${combi}.dat lambda_$lambda 
%     for theta in {10,15,30,50,100,150,200,250,300,400,500,1000,2000,3000,4000,5000,6000,7000,8000,9000,10000,11000,12000,13000,15000,17000,20000,25000,30000,40000,50000,60000,70000,80000,90000,100000,200000};
%     do
%         scp tyche:/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini30b417/lambda_sweep/theta_$lambda/stage/BME_sas_theta${theta}_${combi}.stats.dat lambda_$lambda
%         scp tyche:/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini30b417/lambda_sweep/theta_$lambda/stage/weights_theta${theta}_${combi}.dat lambda_$lambda
%     done  
% done
% done

%colors
grey = [1 1 1]*0.45; % initial (before reweighting)
red = [.95 0 0]; % saxs
black = [0 0 0]; % sans0
green = [0 .7 0]; % sans42
blue = [0 0 1]; % sans70
yellow = [1 1 0]*.7; % all data
TITLE = 1;
fontsize = 20;

%combination for bme and for cross validation 
%0: SAXS, 1: SANS0, 2: SANS42, 3: SANS70, 4:ALL, ...
combi = '0';
combi_cross1 = '1';
combi_cross2 = '2';
combi_cross3 = '3';

% get cross data
data = imp(['lambda_' lambda '/BME_sas_theta200_' combi_cross1 '.stats.dat'],5,2);
q_cross1 = data{1};
I_cross1 = data{2};
dI_cross1 = data{3};
M_cross1 = length(q_cross1);

data = imp(['lambda_' lambda '/BME_sas_theta200_' combi_cross2 '.stats.dat'],5,2);
q_cross2 = data{1};
I_cross2 = data{2};
dI_cross2 = data{3};
M_cross2 = length(q_cross2);

data = imp(['lambda_' lambda '/BME_sas_theta200_' combi_cross3 '.stats.dat'],5,2);
q_cross3 = data{1};
I_cross3 = data{2};
dI_cross3 = data{3};
M_cross3 = length(q_cross3);

%import calc_data
calc_data1 = imp(['lambda_' lambda '/calc_data_' combi_cross1 '.dat'],M_cross1+1,1);
calc_data2 = imp(['lambda_' lambda '/calc_data_' combi_cross2 '.dat'],M_cross2+1,1);
calc_data3 = imp(['lambda_' lambda '/calc_data_' combi_cross3 '.dat'],M_cross3+1,1);

thetas = [10,15,30,50,100,150,200,250,300,400,500,1000,2000,3000,4000,5000,6000,7000,8000,9000,10000,11000,12000,13000,15000,17000,20000,25000,30000,40000,50000,60000,70000,80000,90000,100000,200000];
if strcmp(lambda,'1.06')
    thetas = thetas(2:end);
end
X2 = thetas*0.0; % initialize 
X2_calc1 = X2; % initialize
X2_calc2 = X2; % initialize
X2_calc3 = X2; % initialize
for i = 1:length(thetas)
    theta = num2str(thetas(i));

    % import weights
    data = imp(['lambda_' lambda '/weights_theta' theta '_' combi '.dat'],2,0);
    w = data{2};

    % import bme fit data
    data = imp(['lambda_' lambda '/BME_sas_theta' theta '_' combi '.stats.dat'],5,2);
    q = data{1};
    I = data{2};
    dI = data{3};
    Ifit_before = data{4};
    Ifit_after = data{5};
    M = length(q);
    K = 4; % number of parameters
    
    % calculate cross-weighted intensity
    I_calc1 = q_cross1*0.0; % initialise
    I_calc2 = q_cross2*0.0; % initialise
    I_calc3 = q_cross3*0.0; % initialise
    sumw = sum(w);
    for j = 1:M_cross1
        I_calc1(j) = sum(w.*calc_data1{j+1});
    end
    for j = 1:M_cross2
        I_calc2(j) = sum(w.*calc_data2{j+1});
        I_calc3(j) = sum(w.*calc_data3{j+1});
    end
    for j = 1:M_cross3
        I_calc3(j) = sum(w.*calc_data3{j+1});
    end
    I_calc1 = I_calc1/sumw;
    I_calc2 = I_calc2/sumw;
    I_calc3 = I_calc3/sumw;
    
    % calculate residuals
    R_before = (Ifit_before - I)./dI;
    R_after = (Ifit_after - I)./dI;
    R_calc1 = (I_calc1 - I_cross1)./dI_cross1;
    R_calc2 = (I_calc2 - I_cross2)./dI_cross2;
    R_calc3 = (I_calc3 - I_cross3)./dI_cross3;
    
    % calculate reduced chi square
    chi2r_before = sum(R_before.^2)/(M-K);
    chi2r_after = sum(R_after.^2)/(M-K);
    chi2r_calc1 = sum(R_calc1.^2)/(M-K);
    chi2r_calc2 = sum(R_calc2.^2)/(M-K);
    chi2r_calc3 = sum(R_calc3.^2)/(M-K);
    
    X2(i) = chi2r_after;
    X2_calc1(i) = chi2r_calc1;
    X2_calc2(i) = chi2r_calc2;
    X2_calc3(i) = chi2r_calc3;
end

[value_min_1,index_min_1] =min(X2_calc1);
[value_min_2,index_min_2] =min(X2_calc2);
[value_min_3,index_min_3] =min(X2_calc3);
t0_1 = thetas(index_min_1);
t0_2 = thetas(index_min_2);
t0_3 = thetas(index_min_3);

linewidth = 2.0;

if PLOT_ALL
    Nplots = 5; 
else
    Nplots = 4;
end


figure
if strcmp(lambda,'1.00')
    letter_x = 12;
    letter_y = [170,25,0.83,1.65];
    letter = {'A','B','C','D'};
elseif strcmp(lambda,'1.04')
    letter_x = 12;
    letter_y = [37,12.5,0.83,5.3];
    letter = {'A','B','C','D'};
elseif strcmp(lambda,'1.06')
    letter_x = 17;
    letter_y = [3.3,4.2,0.83,1.6];
    letter = {'E','F','G','H'};
elseif strcmp(lambda,'1.08')
    letter_x = 12;
    letter_y = [16.7,2.53,0.83,1.25];
    letter = {'E','F','G','H'};
end
plot0 = subplot(Nplots,1,1);
text(letter_x,letter_y(1),letter{1},'fontsize',fontsize)
hold on
plot1 = subplot(Nplots,1,2);
text(letter_x,letter_y(2),letter{2},'fontsize',fontsize)
hold on
plot2 = subplot(Nplots,1,3);
text(letter_x,letter_y(3),letter{3},'fontsize',fontsize)
hold on
plot3 = subplot(Nplots,1,4);
text(letter_x,letter_y(4),letter{4},'fontsize',fontsize)
hold on
if PLOT_ALL
    plot4 = subplot(Nplots,1,5);
    hold on
end
%h=line([t0 t0],[floor(min(X2_calc)*10)/10 floor(max(X2_calc)*10)/10],'color',[1 1 1]*0.45,'linewidth',linewidth);
%set(get(get(h,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');

xtick = [1e1 1e2 1e3 1e4 1e5];
xlimits=[10 1e5];
if strcmp(lambda,'1.06')
    xtick = [1e2 1e3 1e4 1e5];
    xlimits=[15 1e5];
end

set(plot0,'fontsize',fontsize,'xscale','log','box','on','xscale','log','xtick',xtick,'xticklabel',[])
set(plot1,'fontsize',fontsize,'xscale','log','box','on','xscale','log','xtick',xtick,'xticklabel',[])
set(plot2,'fontsize',fontsize,'xscale','log','box','on','xscale','log','xtick',xtick,'xticklabel',[])
set(plot3,'fontsize',fontsize,'xscale','log','box','on','xscale','log','xtick',xtick)
if PLOT_ALL
    set(plot4,'fontsize',fontsize,'xscale','log','box','on','xscale','log','xtick',xtick)
    X2_sum = X2*(M-K) + X2_calc1*(M_cross1-K) + X2_calc2*(M_cross2-K) + X2_calc3*(M_cross3-K);
    X2r_sum = X2_sum/(M+M_cross1+M_cross2+M_cross3-4*K);
    %Ng = [M M_cross1 M_cross2 M_cross3]-K;
    Ng = [10.44 4.09 2.88 2.19];
    X2r_sum_w = (X2*Ng(1) + X2_calc1*Ng(2) + X2_calc2*Ng(3) + X2_calc3*Ng(4))/sum(Ng);
end
plot(plot0,thetas,X2,'-','linewidth',linewidth,'color',red)
plot(plot1,thetas,X2_calc1,'-','linewidth',linewidth,'color',black)
plot(plot2,thetas,X2_calc2,'-','linewidth',linewidth,'color',green)
plot(plot3,thetas,X2_calc3,'-','linewidth',linewidth,'color',blue)
if PLOT_ALL
    plot(plot4,thetas,X2r_sum,'-','linewidth',linewidth,'color',yellow)
    %plot(plot4,thetas,X2r_sum_w,'--','linewidth',linewidth,'color',yellow)
end
set(plot0,'xlim',xlimits)
set(plot1,'xlim',xlimits)
set(plot2,'xlim',xlimits)
set(plot3,'xlim',xlimits)
if PLOT_ALL
    set(plot4,'xlim',xlimits)
end

%%% set ylimits, ylabels and legends
ylim0 = get(plot0,'ylim');
ylim2 = [0 1];
ylim1 = get(plot1,'ylim');
ylim3 = get(plot3,'ylim');

if strcmp(lambda,'1.00')
    ylim1 = [0 30];
elseif strcmp(lambda,'1.04')
    ylim0 = [0 44];
    ylim1 = [0 15];
elseif strcmp(lambda,'1.06')
    ylim1 = [0 5];
    ylim3 = [0,2];
elseif strcmp(lambda,'1.08')
    ylim1 = [0 3.0];
    ylim3 = [0 1.5];
elseif strcmp(lambda,'1.10') 
    ylim1 = [0,5];
    ylim3 = [0,1];
end

set(plot0,'ylim',ylim0)
set(plot1,'ylim',ylim1)
set(plot2,'ylim',ylim2)
set(plot3,'ylim',ylim3)

ylabel(plot0,'$\chi^2_r$')
ylabel(plot1,'$\chi^2_r$')
ylabel(plot2,'$\chi^2_r$')
ylabel(plot3,'$\chi^2_r$')

leg0 = legend(plot0,'SAXS');
leg1 = legend(plot1,'SANS 0\% D2O');
leg2 = legend(plot2,'SANS 42\% D2O');
leg3 = legend(plot3,'SANS 70\% D2O');

if PLOT_ALL
    xlabel(plot4,'$\theta$')
    ylabel(plot4,'$\chi^2_r$')
    leg4 = legend(plot4,'SAXS + all SANS');
    set(leg4,'location','northwest','box','off','interpreter','latex')
else
    xlabel(plot3,'$\theta$')
end

set(leg0,'location','north','box','off','interpreter','latex')
set(leg1,'location','north','box','off','interpreter','latex')
set(leg2,'location','north','box','off','interpreter','latex')
set(leg3,'location','north','box','off','interpreter','latex')

%%% set title
if TITLE
    title(plot0,['$\lambda$ = ' lambda])
    title(plot1,['Cross validation with SANS'])
end

%%% save plot
saveplot(['CrossValidation_lambda_' lambda '.png'])
