clear all
close all
clc
set(0,'defaulttextinterpreter','latex')

%%% user input
lambda = '1.10';
combi = '0';

%%% copy (in terminal)
% lambda=1.00; combi=4; scp tyche:/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini30b417/lambda_sweep/theta_$lambda/stage/BME_${combi}.dat lambda_$lambda

% figure settings
grey = [1 1 1]*0.45;
linewidth = 1.7;
fontsize = 20;
fontsize_text = 18;
markersize = 26;
letter = 'B';
lettersize = 20;

% import data
dat = imp(['lambda_' lambda '/BME_' combi '.dat'],4,1);
Theta = dat{1};
Neff = dat{2};
chi2r_before = dat{3};
chi2r_after = dat{4};

% plot data
figure 
%plot1 = subplot(15,1,1);
%hold on
plot2 = subplot(15,1,1:14);
hold on
set(plot2,'fontsize',fontsize,'box','on')
%set(plot1,'visible','off')
plot(Neff,chi2r_after,'k-','linewidth',linewidth)
plot([0;Neff],[1;Neff./Neff],'--','color',grey)

% plot theta lines
range = 1:length(Neff); % default
ymin = 0;
if strcmp(lambda,'1.00')
    if strcmp(combi,'0')
        range = [15 18 22 length(Neff)-11];
        ymax = 160;
        chi_height = 7;
        letter_height = 152;
    elseif strcmp(combi,'1')
        ymax = 100;
        chi_height = 1;
        letter_height = 1;
    elseif strcmp(combi,'2')
        ymin = 1.73;
        ymax = 1.81;
        chi_height = 1;
        letter_height = 1;
    elseif strcmp(combi,'3')
        ymax = 9;
        chi_height = 1;
        letter_height = 1;
    elseif strcmp(combi,'4')
        ymax = 95;
        chi_height = 1;
        letter_height = 1;
    end
elseif strcmp(lambda,'1.04')
    range = [1 6 12 16 26];
    ymax = 35;
    chi_height = 2.1;
    letter_height = 33;
elseif strcmp(lambda,'1.05')
    range = [1 3 5 13];
    ymax = 3;
elseif strcmp(lambda,'1.06')
    range = [1 3 6 11 15];
    ymax = 3;
    chi_height = 0.82;
    letter_height = 2.85;
elseif strcmp(lambda,'1.07')
    range = [3 7 10 13 16];
    ymax = 9;
elseif strcmp(lambda,'1.08')
    range = [1 8 13 25];
    ymax = 20;
    chi_height = 2;
    letter_height = 18.9;
elseif strcmp(lambda,'1.10')
    range = [3 9 12 16];
    ymax = 27;
    chi_height = 2.1;
    letter_height = 25.6;
end

text(0.015,letter_height,letter,'fontsize',lettersize)
text(0.83,chi_height, '$\chi^2_r=1.0$','interpreter','latex','fontsize',fontsize_text)

set(plot2,'ylim',[ymin ymax])
plot(Neff(range),chi2r_after(range),'.k','markersize',markersize)
for i = range
    x = Neff(i);
    line([x x],[chi2r_after(i) ymax],'linestyle',':','color',grey)
    start_text = ymax-ymax*0.28;
    t = text(x-0.025,start_text,['$\theta$ = ' num2str(Theta(i))],'interpreter','latex','fontsize',fontsize_text);
    set(t,'Rotation',90)
end
Theta(range)
ylabel('$\chi^2_r$')
xlabel('$N_{eff}$')

xlim=get(gca,'XLim');
ylim=get(gca,'YLim');

saveplot(['Neff_vs_Chir2r_lambda_' lambda '_combi_' combi '.png'])