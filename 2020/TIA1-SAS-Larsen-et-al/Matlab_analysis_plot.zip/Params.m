clear all
close all
clc
set(0,'defaulttextinterpreter','latex')


lambdas = [1.00,1.01,1.02,1.03,1.04,1.05,1.054,1.056,1.06,1.07,1.08,1.09,1.10,1.20,1.50];
drho = lambdas*0.0; % initialise
r0 = drho*0.0; % initialise
I0 = drho*0.0; % initialise

for i = 1:length(lambdas)
    if i == 7 || i == 8
        lambda = num2str(lambdas(i),'%1.2f');
    else
        lambda = num2str(lambdas(i),'%1.2f');
    end
    dat = imp(['lambda_' lambda '/summary_file'],3,7);
    drho(i) = dat{3}(1);
    dat = imp(['lambda_' lambda '/summary_file'],3,8);
    r0(i) = dat{3}(1);
    dat = imp(['lambda_' lambda '/summary_file'],3,9);
    I0(i) = dat{3}(1);
end

figure
plot1 = subplot(3,1,1);
hold on
plot2 = subplot(3,1,2);
hold on
plot3 = subplot(3,1,3);
hold on
set(plot1,'fontsize',20,'box','on','xticklabel',[])
set(plot2,'fontsize',20,'box','on','xticklabel',[])
set(plot3,'fontsize',20,'box','on')

plot(plot1,lambdas,drho,'k.-','linewidth',2.0,'markersize',16)
plot(plot2,lambdas,r0,'r.-','linewidth',2.0,'markersize',16)
plot(plot3,lambdas,I0,'g.-','linewidth',2.0,'markersize',16)

xlabel(plot2,'$\lambda$')
ylabel(plot1,'$\Delta\rho/\Delta\rho_0$')
ylabel(plot2,'$r_0$')
ylabel(plot3,'$I(0)$')

title(plot1,'Average Ensemble fitted params ')
%title(plot2,'Average Ensemble correction of volumes ')
saveplot('Params')

