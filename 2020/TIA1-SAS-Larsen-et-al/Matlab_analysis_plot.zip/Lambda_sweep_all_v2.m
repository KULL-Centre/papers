clear all
close all
clc
set(0,'defaulttextinterpreter','latex')

%%% user input
linewidth = 1.5;
markersize = 15;
fontsize = 20;
red = [.95 0 0]; % saxs
black = [0 0 0]; % sans0
green = [0 .7 0]; % sans42
blue = [0 0 1]; % sans70
grey = [1 1 1]*0.45; % Rg from simulation

%%% copy (in terminal)
% for lambda in {1.00,1.01,1.02,1.03,1.04,1.05,1.06,1.07,1.08,1.09,1.10,1.20,1.50}; do scp tyche:/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini30b417/lambda_sweep/theta_$lambda/stage/summary_0_file.dat lambda_$lambda; done

colors = {red black green blue};

total_plots = 5;    
figure

plot0 = subplot(total_plots,1,1);
hold on
text(1.003,9,'A','fontsize',fontsize)
h = line([1.06 1.06],[0 70],'color',[1 1 1]*0.3,'linewidth',linewidth);
set(get(get(h,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
text(1.064,35,'$\lambda_{min(\chi^2_r)} = 1.06$','color',[1 1 1]*0.3,'fontsize',fontsize-2)

plot1 = subplot(total_plots,1,2);
hold on
text(1.003,4.5,'B','fontsize',fontsize)
h = line([1.08 1.08],[0 70],'color',[1 1 1]*0.3,'linewidth',linewidth);
set(get(get(h,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
text(1.084,14,'$\lambda_{min(\chi^2_r)} = 1.08$','color',[1 1 1]*0.3,'fontsize',fontsize-2)

plot2 = subplot(total_plots,1,3);
hold on
text(1.003,1.763,'C','fontsize',fontsize)

plot3 = subplot(total_plots,1,4);
hold on
text(1.003,0.8,'D','fontsize',fontsize)
h = line([1.08 1.08],[0 70],'color',[1 1 1]*0.3,'linewidth',linewidth);
set(get(get(h,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
text(1.084,2.7,'$\lambda_{min(\chi^2_r)} \ge 1.08$','color',[1 1 1]*0.3,'fontsize',fontsize-2)

plot4 = subplot(total_plots,1,5);
text(1.265,30.5,'Exp. $R_g$ (SAXS)','color',red,'fontsize',fontsize-2)
hold on
text(1.003,35,'E','fontsize',fontsize)


%lambda vector
%lambda = [1.00:0.01:1.05 1.052:0.002:1.06 1.07:0.01:1.10 1.20 1.50];
lambda = [1.00:0.01:1.10 1.20 1.50];

%initialize min values
minimum_chi = zeros(4,1);
index_minimum_chi = minimum_chi;
minimum_lambda = minimum_chi;

% SAXS
j = 1;
combi = '0';
N_lambda = length(lambda);
Chi2r = zeros(1,N_lambda); % initialize chi2r
Rg = Chi2r*0.0; % initialize Rg
dRg = Chi2r*0.0; % initialize dRg
for i = 1:N_lambda
    if lambda(i) > 1.05 && lambda(i) < 1.06
        data = imp(['lambda_' num2str(lambda(i),'%1.3f') '/Dist_all.txt'],5,1);
    else
        data = imp(['lambda_' num2str(lambda(i),'%1.2f') '/Dist_all.txt'],5,1);
    end
    time = data{1}(1:end-1)./1000; % time converted to us
    dist12 = data{2}(1:end-1)*10;
    dist13 = data{3}(1:end-1)*10;
    dist23 = data{4}(1:end-1)*10;
    Rg_vector = data{5}(1:end-1)*10;

    if lambda(i) > 1.05 && lambda(i) < 1.06
        data = imp(['lambda_' num2str(lambda(i),'%1.3f') '/summary_0_file.dat'],9,1);
        Rg_dat = imp(['lambda_' num2str(lambda(i),'%1.3f') '/Rg.stat'],14,0);
    else
        data = imp(['lambda_' num2str(lambda(i),'%1.2f') '/summary_0_file.dat'],9,1);
        Rg_dat = imp(['lambda_' num2str(lambda(i),'%1.2f') '/Rg.stat'],14,0);
    end
    dRg(i) = Rg_dat{14}*10;
    Chi2r(i) = data{3}(1);
    Rg(i) = mean(Rg_vector);
end
[minimum_chi(j),index_minimum_chi(j)] = min(Chi2r);
minimum_lambda(j) = lambda(index_minimum_chi(j));
set(plot0,'fontsize',fontsize,'box','on','xscale','lin','yscale','lin','xtick',[],'xlim',[1 1.5],'ylim',[0 max(Chi2r)])
plot(plot0,lambda,Chi2r,'.-','markersize',markersize,'linewidth',linewidth,'color',red)
ylabel(plot0,'$\chi^2_r$')
leg = legend(plot0,'SAXS');
set(leg,'box','off','interpreter','latex','fontsize',fontsize)

% SANS0
j = 2;
combi = '1';
N_lambda = length(lambda);
Chi2r = zeros(1,N_lambda); % initialize chi2r
Rg = Chi2r*0.0; % initialize Rg
dRg = Chi2r*0.0; % initialize dRg
for i = 1:N_lambda
    if lambda(i) > 1.05 && lambda(i) < 1.06
        data = imp(['lambda_' num2str(lambda(i),'%1.3f') '/Dist_all.txt'],5,1);
    else
        data = imp(['lambda_' num2str(lambda(i),'%1.2f') '/Dist_all.txt'],5,1);
    end
    time = data{1}(1:end-1)./1000; % time converted to us
    dist12 = data{2}(1:end-1)*10;
    dist13 = data{3}(1:end-1)*10;
    dist23 = data{4}(1:end-1)*10;
    Rg_vector = data{5}(1:end-1)*10;

    if lambda(i) > 1.05 && lambda(i) < 1.06
        data = imp(['lambda_' num2str(lambda(i),'%1.3f') '/summary_0_file.dat'],9,1);
        Rg_dat = imp(['lambda_' num2str(lambda(i),'%1.3f') '/Rg.stat'],14,0);
    else
        data = imp(['lambda_' num2str(lambda(i),'%1.2f') '/summary_0_file.dat'],9,1);
        Rg_dat = imp(['lambda_' num2str(lambda(i),'%1.2f') '/Rg.stat'],14,0);
    end
    dRg(i) = Rg_dat{14}*10;
    Chi2r(i) = data{3}(2);
    Rg(i) = mean(Rg_vector);
end
[minimum_chi(j),index_minimum_chi(j)] = min(Chi2r);
minimum_lambda(j) = lambda(index_minimum_chi(j));
set(plot1,'fontsize',fontsize,'box','on','xscale','lin','yscale','lin','xtick',[],'xlim',[1 1.5],'ylim',[0 max(Chi2r)])
plot(plot1,lambda,Chi2r,'.-','markersize',markersize,'linewidth',linewidth,'color',black)
ylabel(plot1,'$\chi^2_r$')
leg = legend(plot1,'SANS 0\% D$_2$O');
set(leg,'box','off','interpreter','latex','fontsize',fontsize)

% SANS42
j = 3;
leg = legend(plot2,'SANS 42\% D$_2$O');
set(leg,'box','off','interpreter','latex','fontsize',fontsize)
combi = '2';
N_lambda = length(lambda);
Chi2r = zeros(1,N_lambda); % initialize chi2r
Rg = Chi2r*0.0; % initialize Rg
dRg = Chi2r*0.0; % initialize dRg
for i = 1:N_lambda
    if lambda(i) > 1.05 && lambda(i) < 1.06
        data = imp(['lambda_' num2str(lambda(i),'%1.3f') '/Dist_all.txt'],5,1);
    else
        data = imp(['lambda_' num2str(lambda(i),'%1.2f') '/Dist_all.txt'],5,1);
    end
    time = data{1}(1:end-1)./1000; % time converted to us
    dist12 = data{2}(1:end-1)*10;
    dist13 = data{3}(1:end-1)*10;
    dist23 = data{4}(1:end-1)*10;
    Rg_vector = data{5}(1:end-1)*10;

    if lambda(i) > 1.05 && lambda(i) < 1.06
        data = imp(['lambda_' num2str(lambda(i),'%1.3f') '/summary_0_file.dat'],9,1);
        Rg_dat = imp(['lambda_' num2str(lambda(i),'%1.3f') '/Rg.stat'],14,0);
    else
        data = imp(['lambda_' num2str(lambda(i),'%1.2f') '/summary_0_file.dat'],9,1);
        Rg_dat = imp(['lambda_' num2str(lambda(i),'%1.2f') '/Rg.stat'],14,0);
    end
    dRg(i) = Rg_dat{14}*10;
    Chi2r(i) = data{3}(3);
    Rg(i) = mean(Rg_vector);
end
[minimum_chi(j),index_minimum_chi(j)] = min(Chi2r);
minimum_lambda(j) = lambda(index_minimum_chi(j));
set(plot2,'fontsize',fontsize,'box','on','xscale','lin','yscale','lin','xtick',[],'xlim',[1.0 1.5],'ylim',[1.75 max(Chi2r)])
plot(plot2,lambda,Chi2r,'.-','markersize',markersize,'linewidth',linewidth,'color',green)
ylabel(plot2,'$\chi^2_r$')
leg = legend(plot2,'SANS 42\% D$_2$O');
set(leg,'box','off','interpreter','latex','fontsize',fontsize)
%[lambda',Chi2r']

% SANS70
j = 4;
combi = '3';
N_lambda = length(lambda);
Chi2r = zeros(1,N_lambda); % initialize chi2r
Rg = Chi2r*0.0; % initialize Rg
dRg = Chi2r*0.0; % initialize dRg
for i = 1:N_lambda
    if lambda(i) > 1.05 && lambda(i) < 1.06
        data = imp(['lambda_' num2str(lambda(i),'%1.3f') '/Dist_all.txt'],5,1);
    else
        data = imp(['lambda_' num2str(lambda(i),'%1.2f') '/Dist_all.txt'],5,1);
    end
    time = data{1}(1:end-1)./1000; % time converted to us
    dist12 = data{2}(1:end-1)*10;
    dist13 = data{3}(1:end-1)*10;
    dist23 = data{4}(1:end-1)*10;
    Rg_vector = data{5}(1:end-1)*10;

    if lambda(i) > 1.05 && lambda(i) < 1.06
        data = imp(['lambda_' num2str(lambda(i),'%1.3f') '/summary_0_file.dat'],9,1);
        Rg_dat = imp(['lambda_' num2str(lambda(i),'%1.3f') '/Rg.stat'],14,0);
    else
        data = imp(['lambda_' num2str(lambda(i),'%1.2f') '/summary_0_file.dat'],9,1);
        Rg_dat = imp(['lambda_' num2str(lambda(i),'%1.2f') '/Rg.stat'],14,0);
    end
    dRg(i) = Rg_dat{14}*10;
    Chi2r(i) = data{3}(4);
    Rg(i) = mean(Rg_vector);
end
[minimum_chi(j),index_minimum_chi(j)] = min(Chi2r);
minimum_lambda(j) = lambda(index_minimum_chi(j));
set(plot3,'fontsize',fontsize,'box','on','xscale','lin','yscale','lin','xtick',[],'xlim',[1.0 1.5],'ylim',[0 max(Chi2r)])
plot(plot3,lambda,Chi2r,'.-','markersize',markersize,'linewidth',linewidth,'color',blue)
ylabel(plot3,'$\chi^2_r$')
leg = legend(plot3,'SANS 70\% D$_2$O');
set(leg,'box','off','interpreter','latex','fontsize',fontsize)

% Rg plot
Rg_exp = 27.7;
axis(plot4,[1 1.5 18 40])
set(plot4,'fontsize',fontsize,'box','on','xscale','lin','yscale','lin','xtick',[1 1.1 1.2 1.3 1.4 1.5])
errorbar(plot4,lambda,Rg,dRg,'.-','markersize',markersize,'linewidth',linewidth,'color',grey)
plot(plot4,lambda,Rg_exp*lambda./lambda,'-','linewidth',linewidth,'color',red);
ylabel(plot4,'$R_g$ [\AA]')
xlabel(plot4,'$\lambda$')
leg = legend(plot4,'$R_g$ from the simulation');
set(leg,'box','off','interpreter','latex','fontsize',fontsize,'location','southeast')

% save plot
saveplot(['Lambda_sweep_small'])
