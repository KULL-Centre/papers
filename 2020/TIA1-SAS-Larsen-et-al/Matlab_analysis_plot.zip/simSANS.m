% compare slightly different distributions with SAXS and simulated SANS

clear all
close all
clc
set(0,'defaulttextinterpreter','latex')

% user input
linewidth = 3.2;
markersize = 12;
Rmax = .12;
xtick = [0.01 0.03 0.1 0.3];
fontsize = 20;

%%% copy (in terminal)
% for lambda in {1.04,1.06,1.08,1.10}; 
% do 
%     for theta in {150,300};
%     do
%         scp tyche:/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini30b417/lambda_sweep/theta_$lambda/stage/weights_theta${theta}_0.dat lambda_$lambda
%     done 
%     scp tyche:/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini30b417/lambda_sweep/theta_$lambda/sim/AA_frame0chain_saxs.fit lambda_$lambda
%     scp tyche:/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini30b417/lambda_sweep/theta_$lambda/sim/AA_frame0chain_deut69_d2o100_chainA.fit lambda_$lambda
%     scp tyche:/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini30b417/lambda_sweep/theta_$lambda/sim/AA_frame0chain_deut69_d2o100_chainB.fit lambda_$lambda
%     scp tyche:/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini30b417/lambda_sweep/theta_$lambda/sim/AA_frame0chain_deut69_d2o100_chainC.fit lambda_$lambda
%     for combi in {'0','1','2','3'}
%     do
%         scp tyche:/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini30b417/lambda_sweep/theta_$lambda/sim/sim_data_${combi}.dat lambda_$lambda
%     done
% done


combis = {'0', '1', '2', '3'};
headers = {'SAXS', 'SANS, RRM-1 69$\%$ deut., 100$\%$ D2O', 'SANS, RRM-2 69$\%$ deut., 100$\%$ D2O', 'SANS, RRM-3 69$\%$ deut., 100$\%$ D2O'};
combi_names = {'saxs' 'deut69_d2o100_chainA' 'deut69_d2o100_chainB' 'deut69_d2o100_chainC'};
letters = {'A','B','C','D'};

for k = 1:length(combis)
    combi = combis{k};
    header = headers{k};
    combi_name = combi_names{k};
    letter = letters{k};
    
    figure
    plot1 = subplot(5,1,1:4);
    text(0.0105,1.3,letter,'fontsize',fontsize);
    hold on 
    plot2 = subplot(5,1,5);
    hold on 

    set(plot1,'fontsize',fontsize,'xscale','log','yscale','log','box','on','xtick',xtick,'xticklabel',[])
    set(plot2,'fontsize',fontsize,'xscale','log','yscale','lin','box','on','ytick',[-Rmax 0 Rmax],'xtick',xtick,'xticklabel',xtick)

    lambdas = {'1.06','1.04','1.08','1.10'};
    colors = {[0.1500    0.9500    0.1500] [0 .2 1] [0.63    0.43    0.22] [.8 0 0]};
    markers = {'-', '--', ':','-.'};
    thetas = {'300','150','150','300'};

    for i = 1:3%length(lambdas)
        lambda = lambdas{i};
        color = colors{i};
        marker = markers{i};
        theta = thetas{i};

        % weights from SAXS
        data = imp([ 'lambda_' lambda '/weights_theta' theta '_0.dat'],2,0);
        w = data{2};
        
        % get length of q
        data = imp(['lambda_' lambda '/AA_frame0chain_' combi_name '.fit'],5,6);
        q = data{1};
        M = length(q);

        % get simulated data
        sim_data = imp(['lambda_' lambda '/sim_data_' combi '.dat'],M+1,1);

        I_sim = q*0.0; % initialise
        sumw = sum(w);
        for j = 1:M
            I_sim(j) = sum(w.*sim_data{j+1});
        end
        I_sim = I_sim/sumw;
        I_sim = I_sim/max(I_sim);

        if i == 1
            I_calc_1 = I_sim; % save for residuals
        end

        R_calc = (I_sim - I_calc_1)./I_calc_1;
        
        plot(plot1,q,I_sim,marker,'color',color,'linewidth',linewidth,'markersize',markersize)
        plot(plot2,q,R_calc,marker,'color',color,'linewidth',linewidth,'markersize',markersize)
    end

    axis(plot1,[1e-2 0.7  1e-3 2])
    axis(plot2,[1e-2 0.7 -Rmax Rmax])
    xlabel(plot2,'$q$ [\AA$^{-1}$]')
    ylabel(plot1,'$I$ [cm$^{-1}$]')
    ylabel(plot2,'$\Delta I/I$')
    
    if k == 1
        leg1 = legend(plot1,'Distr. 1 ($\lambda=1.06$)','Distr. 2 ($\lambda=1.04$)','Distr. 3 ($\lambda=1.08$)','Distr. 4 ($\lambda=1.10$)');
        set(leg1,'fontsize',fontsize,'interpreter','latex','box','off')
    end
    title(plot1,header);
    
    saveplot(['simSANS_combi' combi '.png'])
end
