clear all
close all
clc
set(0,'defaulttextinterpreter','latex')
    
%%% user input
lambda = '1.10';
combi = '0';

%%% copy (in terminal)
% theta=500; lambda=1.00; combi=4; scp tyche:/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini30b417/lambda_sweep/theta_$lambda/stage/BME_sas_theta${theta}_${combi}.stats.dat lambda_$lambda

%%% figure layout
linewidth = 2.0;
markersize = 11;
fontsize = 20;
xtick = [0.03 0.1 0.3];
green = [0 .8 0];
purple = [1 0 1];
cyan = [0 1 1];
colors = {green};
letter = 'A';
lettersize = 20;
xmin = 0.0155;
xmax = 0.55;

%%% choices depending on lambda
if strcmp(lambda,'1.00')
    if strcmp(combi,'0')
        thetas = {'150' '500' '5000' };
        colors = {cyan green purple};
    elseif strcmp(combi,'1')
        thetas = {'150'};
    elseif strcmp(combi,'2')
        thetas = {'10'};
    elseif strcmp(combi,'3')
        thetas = {'10'};
    elseif strcmp(combi,'4')
        thetas = {'500'};
    end
    Rmax = 50;
elseif strcmp(lambda,'1.04')
    thetas = {'500'};
    Rmax = 25;
elseif strcmp(lambda,'1.06')
    thetas = {'500'};
    Rmax = 8;
elseif strcmp(lambda,'1.08')
    thetas = {'300'};
    Rmax = 20;
elseif strcmp(lambda,'1.10')
    thetas = {'300'};
    Rmax = 25;
end

%%% figure settings
figure
plot1 = subplot(5,1,1:4);
text(0.0165,0.029,letter,'fontsize',lettersize)
hold on 
plot2 = subplot(5,1,5);
hold on 
set(plot1,'fontsize',fontsize,'xscale','log','yscale','log','box','on','xtick',xtick,'xticklabel',[])
set(plot2,'fontsize',fontsize,'xscale','log','yscale','lin','box','on','xtick',xtick,'xticklabel',xtick,'ytick',[-Rmax 0 Rmax])

%%% loop over thetas
legelements{1} = 'TIA-1, SAXS';
for i = 1:length(thetas)
    theta = thetas{i};
    color = colors{i};
    
    %%% import
    data = imp(['lambda_' lambda '/BME_sas_theta' theta '_' combi '.stats.dat'],5,2);
    q = data{1};
    I = data{2};
    dI = data{3};
    Ifit_before = data{4};
    Ifit_after = data{5};
    M = length(q);
    K = 4; % number of parameters

    %%%% calculate residuals
    R_before = (Ifit_before - I)./dI;
    R_after = (Ifit_after - I)./dI;

    %%%% calculate reduced chi square
    chi2r_before = sum(R_before.^2)/(M-K);
    chi2r_after = sum(R_after.^2)/(M-K);

    %%%% plot
    if i == 1; errorbar(plot1,q,I,dI,'r.','markersize',markersize); end
    if i == 1; plot(plot1,q,Ifit_before,'k-','linewidth',linewidth); end
    plot(plot1,q,Ifit_after,'-','color',color,'linewidth',linewidth)

    if i == 1; plot(plot2,q,I,'r.','markersize',markersize); end
    if i == 1; plot(plot2,q,R_before,'-k','linewidth',linewidth); end
    plot(plot2,q,R_after,'-','color',color,'linewidth',linewidth)
    
    if i == 1; legelements{i+1} = ['CG-MD $\chi^2_r$ = ' num2str(chi2r_before,'%1.1f')]; end
    legelements{i+2} = ['CG-MD, BME, $\theta$ = ' num2str(theta) ', $\chi^2_r$ = ' num2str(chi2r_after,'%1.1f')];
end

leg1 = legend(plot1, legelements);
set(leg1,'interpreter','latex','box','off','location','southwest')

xlabel(plot2,'$q$ [\AA$^{-1}$]')
ylabel(plot1,'$I$ [cm$^{-1}$]')
ylabel(plot2,'$\Delta I/\sigma$')
if strcmp(combi,'0')
    axis(plot1,[xmin xmax 3e-5 0.045])
end
axis(plot2,[xmin xmax -Rmax Rmax])

%%% save plot
saveplot(['Fit_lambda_' lambda '_theta_' theta '_combi_' combi '.png'])

%makefile for bayesapp
fid = fopen('Fit_for_bayesapp.dat','w');
for i = 1:M
   fprintf(fid,'%e \t %e \t %e\n', q(i),Ifit_after(i),dI(i));
end
fclose(fid);

