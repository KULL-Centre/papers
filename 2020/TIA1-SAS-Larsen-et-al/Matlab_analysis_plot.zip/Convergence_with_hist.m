clear all
close all
clc
set(0,'defaulttextinterpreter','latex')

%%% user input
lambda = '1.00';
combi = '0'; % 0 for SAXS
column = '5'; % 2 for D12, 3 for D13, 5 for Rg

%%% layout
fontsize = 18.5;
linewidth = 3;
markersize = 8;
grey = [1 1 1]*0.35;
green = [0 .8 0];
purple = [1 0 1];
cyan = [0 1 1];
colors = {green};

% theta value depends on lambda value
if strcmp(lambda,'1.00')
    if strcmp(combi,'0')
        thetas = {'150' '500' '5000'};
        colors = {cyan green purple};
    elseif strcmp(combi,'1')
        thetas = {'150'};
    end
elseif strcmp(lambda,'1.04')
    thetas = {'500'};
elseif strcmp(lambda,'1.06')
    thetas = {'500'};
elseif strcmp(lambda,'1.08')
    thetas = {'300'};
elseif strcmp(lambda,'1.10')
    thetas = {'300'};
end

if strcmp(column,'5')
    filename = 'Rg';
    variable_name = 'R_g';
    letter = 'C';
    if strcmp(lambda,'1.00')
        letter_y = 34.2;
        ymax = 35;
        xtick = [0 5000];
    elseif strcmp(lambda,'1.04')
        letter_y = 48;
        ymax = 50;
        xtick = [0 2500];
    elseif strcmp(lambda,'1.06')
        letter_y = 53.1;
        ymax = 55;
        xtick = [0 1500];
    elseif strcmp(lambda,'1.08')
        letter_y = 53.1;
        ymax = 55;
        xtick = [0 2000];
    elseif strcmp(lambda,'1.10')
        letter_y = 58;
        ymax = 60;
        xtick = [0 2000];
    end
elseif strcmp(column,'3')
    filename = 'D13';
    variable_name = 'D_{13}';
    letter = 'D';
    if strcmp(lambda,'1.00')
        letter_y = 67.5;
        ymax = 70;
        xtick = [0 3000];
    elseif strcmp(lambda,'1.04')
        letter_y = 86;
        ymax = 90;
        xtick = [0 1200];
    elseif strcmp(lambda,'1.06')
        letter_y = 91;
        ymax = 95;
        xtick = [0 700];
    elseif strcmp(lambda,'1.08')
        letter_y = 91;
        ymax = 95;
        xtick = [0 1000];
    elseif strcmp(lambda,'1.10')
        letter_y = 91;
        ymax = 95;
        xtick = [0 800];
    end
elseif strcmp(column,'2')
    filename = 'D12';
    variable_name = 'D_{12}';
end

    
%%% figure settings
figure
plot1=subplot(1,5,1:4);
text(0.25,letter_y,letter,'fontsize',fontsize)
hold on
plot2=subplot(1,5,5);
hold on
set(plot1,'fontsize',fontsize,'box','on')
set(plot2,'fontsize',fontsize,'box','on','yticklabel',[],'xtick',xtick)
legendinfo{1} = ['Simulated $\langle ' variable_name ' \rangle$'];

% import distances
data = imp(['lambda_' lambda '/Dist_all.txt'],5,1);
time = data{1}(1:end-1)./1000; % time converted to us
rg     = data{5}(1:end-1)*10;
rg_sim = mean(rg);
rg_exp = 27.7;
    
for i = 1:length(thetas)
    theta = thetas{i};
    color = colors{i};
    
    % import weights
    data_w = imp(['lambda_' lambda '/weights_theta' theta '_' combi '.dat'],2,0);
    w = data_w{2};

    % weighted averages
    cv = data{str2double(column)}(1:end-1)*10; %collective variable
    cv = cv(1:length(w)); % truncate cv if not all frames were used in BME
    time = time(1:length(w)); % truncate time
    cv_bme = sum(w.*cv)/sum(w); % cv from dist_all file
    cv_sim = mean(cv);

    % plot
    if i == 1; 
        h=plot(plot1,time,cv,'.','markersize',markersize,'color',grey);
        set(get(get(h,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
        plot(plot1,time,cv_sim*time./time,'-','linewidth',linewidth,'color',[1 1 1]*0)
    end
    plot(plot1,time,cv_bme*time./time,'-','color',color,'linewidth',linewidth)
    
    if strcmp(column,'5') && i == length(thetas)
        plot(plot1,time,rg_exp*time./time,'--r','linewidth',linewidth)
    end
    xlabel(plot1,'time [$\mu$s]')

    %if strcmp(lambda,'1.00') && strcmp(column,'5')
    %    set(plot1,'ylim',[18 31])
    %elseif strcmp(lambda,'1.06') && strcmp(column,'5')
    %    set(plot1,'ylim',[20 55])
    %end

    hist_weighted = imp(['lambda_' lambda '/Distribution_combi_' combi '_column_' column '_theta_' theta '.dat'],2,0);
    x = hist_weighted{1};
    y = hist_weighted{2};
    plot(plot2,y,x,'-','color',color,'linewidth',linewidth);
    hist_nonweighted = imp(['lambda_' lambda '/Distribution_combi_99_column_' column '.dat'],2,0);
    x = hist_nonweighted{1};
    y = hist_nonweighted{2};
    plot(plot2,y,x,'color',grey,'linewidth',linewidth);

    a = get(plot2,'xlim');
    if strcmp(column,'5') && i == length(thetas)
        plot(a,rg_exp*ones(size(a)),'--r','linewidth',linewidth)
    end
    legendinfo{i+1} = ['Reweighted $\langle ' variable_name ' \rangle$, $\theta=' theta '$'];
end

legendinfo{i+2} = ['Experimental $\langle ' variable_name ' \rangle$ (SAXS)'];

leg1=legend(plot1,legendinfo);
set(leg1,'interpreter','latex','fontsize',fontsize,'box','off','location','northeast')
    
ylabel(plot1,['$' variable_name '$ [\AA]'])  
ylimits=get(plot1,'ylim');
if strcmp(combi,'0')
    set(plot1,'ylim',[ ylimits(1) ymax]);
    set(plot2,'ylim',[ ylimits(1) ymax]);
end
set(plot2,'xlim',xtick)
xlabel(plot2,'structures')

saveplot([filename '_lambda_' lambda '_theta_' theta '.png'])