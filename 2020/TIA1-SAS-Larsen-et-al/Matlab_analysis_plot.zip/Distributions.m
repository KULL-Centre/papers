clear all
close all
clc
set(0,'defaulttextinterpreter','latex')

%%% user input

lambda = '1.00'; 
combi = '4'; %0: SAXS, 1: SANS0, 2: SANS42, 3: SANS70, 4:ALL, ... 99: initial distribution
column = 5; % 2: D12, 3: D13, 4: D23, 5: Rg

%%% copy (in terminal)
% theta=500; lambda=1.00; combi=4; scp tyche:/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini30b417/lambda_sweep/theta_$lambda/stage/weights_theta${theta}_${combi}.dat lambda_$lambda

%%% figure layout
linewidth = 2.0;
markersize = 11;
rg_exp = 27.7;
xlimits = [15 45];
TITLE = 0; % no title
legend_location = 'northeast';

%%% import
if strcmp(lambda,'1.00')
    if strcmp(combi,'0')
        thetas = {'500' '5000' '150'};
    elseif strcmp(combi,'1')
        thetas = {'150'};
    elseif strcmp(combi,'2')
        thetas = {'10'};
    elseif strcmp(combi,'3')
        thetas = {'10','30','300'};
    elseif strcmp(combi,'4')
        thetas = {'50'};
    end
elseif strcmp(lambda,'1.04')
    thetas = {'500'};
elseif strcmp(lambda,'1.05')
    thetas = {'40'};
elseif strcmp(lambda,'1.06')
    thetas = {'500'};
elseif strcmp(lambda,'1.07')
    thetas = {'20'};
elseif strcmp(lambda,'1.08')
    thetas = {'300'};
elseif strcmp(lambda,'1.10')
    thetas = {'300'};
end
scale = 10;
% for histogram
nbin = 50;
N = 200;
if column == 5
    binlimits = [0,60];
else
    binlimits = [0,80];
end
dbin = (binlimits(2)-binlimits(1))/nbin;

naming_columns = {'dummy','$D_{12}$','$D_{13}$','$D_{23}$','$R_g$'};

%%% plot settings
% figure settings
figure
hold on
set(gca,'fontsize',20,'xscale','lin','yscale','lin','box','on')%,'xlim',xlimits)
green = [0 .8 0];
purple = [1 0 1];
cyan = [0 1 1];
colors = {green purple cyan};

% import distances
data = imp(['lambda_' lambda '/Dist_all.txt'],5,1);
time = data{1}(1:end-1)/1000; % time in us
p = data{column}(1:end-1)*10;
    
%%% loop over thetas
for i = 1:length(thetas)
    theta = thetas{i};
    color = colors{i};
    
    % import weights
    data = imp(['lambda_' lambda '/weights_theta' theta '_' combi '.dat'],2,0);
    w = data{2};
    W = w*length(w);
    p = p(1:length(w)); % truncate p to make it same size as w (if all frames were not used in BME)

    %%% plot results

    % make non-reweighted histogram
    h=histogram(p,nbin,'binlimits',binlimits,'visible','off');
    set(get(get(h,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
    x = binlimits(1)+dbin/2:dbin:binlimits(2);
    y = h.Values;

    % make reweighted histogram
    Nh = length(h.Data);
    wh = zeros(Nh,N);
    for ii=1:Nh
        n = round(scale*W(ii));
        wh(ii,1:n) = repmat(h.Data(ii),1,n);
    end
    nonzero_elements = find(wh); % only include non-zero elements in histogram
    hw = histogram(wh(nonzero_elements),nbin,'binlimits',binlimits,'visible','off');
    set(get(get(hw,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
    yw = hw.Values/scale;

    if i == 1; plot(x,y,'-k','linewidth',linewidth); legendinfo{i} = 'Before reweighting'; end
    plot(x,yw,'-','color',color,'linewidth',linewidth)
    legendinfo{i+1} = ['After reweighting, $\theta=' theta '$'];

    % export reweighted histogram
    fid = fopen(['lambda_' lambda '/Distribution_combi_' combi '_column_' num2str(column) '_theta_' theta '.dat'],'w');
    for ii = 1:nbin
       fprintf(fid,'%f  \t  %f  \n',x(ii),yw(ii)); 
    end
    fclose(fid);

end
legendinfo{i+2} = 'Experimental (SAXS)';

if column == 2
    xlabel('$D_{12}$ [\AA]')
elseif column == 3
    xlabel('$D_{13}$ [\AA]')
elseif column == 4
    xlabel('$D_{23}$ [\AA]')    
elseif column == 5
    line([rg_exp rg_exp],ylim,'color',[1 0 0],'linewidth',linewidth)
    xlabel('$R_g$ [\AA]')
end


% labels
ylabel('Number of structures')
legend(legendinfo)
set(legend, 'interpreter','latex','box','off','fontsize',15,'location',legend_location)

if TITLE
    title([naming_columns{column} ' distribution, $\lambda$ = ' lambda ', combi ' combi]);
end

% save plot
saveplot(['lambda_' lambda '/Distribution_combi_' combi '_column_' num2str(column) '_theta_' theta])

% export non-reweighted histogram
fid = fopen(['lambda_' lambda '/Distribution_combi_99_column_' num2str(column) '.dat'],'w');
for i = 1:nbin
   fprintf(fid,'%f  \t  %f  \n',x(i),y(i)); 
end
fclose(fid);

% % check exported data:
% data = imp(['lambda_' lambda '/Distribution_combi_' combi '_column_' num2str(column) '.dat'],2,0);
% plot(data{1},data{2},'--b')
% data = imp(['lambda_' lambda '/Distribution_combi_99_column_' num2str(column) '.dat'],2,0);
% plot(data{1},data{2},'--r')