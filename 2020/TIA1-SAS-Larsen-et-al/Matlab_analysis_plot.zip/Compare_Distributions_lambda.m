clear all
close all
clc
set(0,'defaulttextinterpreter','latex')

%%% user input

column = 3; % 2: D12, 3: D13, 4: D23, 5: Rg
combi = '0';
SHOW_ONLY_BEST_RANGE = 0;
lambdas = {'1.00','1.04','1.06','1.08','1.10'};
thetas = {'500','500','500','300','300'};

%%% figure layout
naming_columns = {'dummy','D12','D13','D23','Rg'};
smooth_factor = 1; % smooth (1: no smoothing)
colors = {[0         0    0] [0 .2 1] [0.1500    0.9500    0.1500] [0.63    0.43    0.22] [0.9500         0         0] [1 .5 0] [0 1 1]};
linewidth = 2.0;
markersize = 11;
rg_exp = 27.7;
leg = 0;
fontsize = 20;
lettersize = 20;

figure 
hold on
set(gca,'box','on','fontsize',fontsize)
if SHOW_ONLY_BEST_RANGE
    range = 2:4;
else
    range = 1:length(lambdas);
end

for i = range
    color = colors{i};
    theta = thetas{i};
    lambda = lambdas{i};
    data = imp(['lambda_' lambda '/Distribution_combi_' combi '_column_' num2str(column) '_theta_' theta '.dat'],2,0);
    x = data{1};
    y = data{2};
    plot(x,smooth(y,smooth_factor),'linewidth',linewidth,'color',color);
    leg = leg+1;
    %legendinfo{leg} = [naming_columns{column} ', $\lambda$ = ' lambda ', $\theta$ = ' theta];
    legendinfo{leg} = ['$\lambda$ = ' lambda ', $\theta$ = ' theta];
end

ylabel('Number of structures')
if column == 2
    xlabel('$D_{12}$ [\AA]')
    legend_location = 'northeast';
elseif column == 3
    xlabel('$D_{13}$ [\AA]')
    if SHOW_ONLY_BEST_RANGE
        axis([15 80 0 1000])
    else
        axis([15 80 0 2200])
    end
    legend_location = 'northeast';
    letter = 'B';
    letter_x = 17;
    letter_y = 2070;
elseif column == 4
    xlabel('$D_{23}$ [\AA]')  
    legend_location = 'northeast';
elseif column == 5
    line([rg_exp rg_exp],[0 20000],'color',[1 1 1]*0.45,'linewidth',linewidth+0.5,'linestyle','--')
    xlabel('$R_g$ [\AA]')
    if SHOW_ONLY_BEST_RANGE
        axis([15 50 0 2000])
    else
        axis([15 50 0 3600])
    end
    legend_location = 'northeast';
    letter = 'A';
    letter_x = 16;
    letter_y = 3400;
end
legendinfo{leg+1} = 'Experimental Rg';

if column == 5
    legend(legendinfo)
    set(legend,'interpreter','latex','fontsize',fontsize,'box','off','location',legend_location)
end
text(letter_x,letter_y,letter,'fontsize',lettersize)

if SHOW_ONLY_BEST_RANGE
    saveplot(['Compare_Distributions_combi_' combi '_' naming_columns{column} '_bestrange']) 
else
    saveplot(['Compare_Distributions_combi_' combi '_' naming_columns{column}])
end