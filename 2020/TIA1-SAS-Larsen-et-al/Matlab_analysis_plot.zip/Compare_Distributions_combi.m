clear all
close all
clc
set(0,'defaulttextinterpreter','latex')

%%% user input
% layout
linewidth = 2.0;
markersize = 11;
rg_exp = 27.7;

grey = [1 1 1]*0.45; % initial (before reweighting)
red = [.95 0 0]; % saxs
black = [0 0 0]; % sans0
green = [0 .7 0]; % sans42
blue = [0 0 1]; % sans70
yellow = [1 1 0]*.7; % all data
TITLE = 0;

%%% user input
column = 3; % 2: D12, 3: D13, 4: D23, 5: Rg
lambda = '1.00';
range = 1:6;

%%% settings for combis
combis = {'99','0','1','2','3','4'};
thetas = {'','500','150','10','10','500'};
combi_names = {'Initial distribution','SAXS', 'SANS (0\% D2O)','SANS (42\% D2O)','SANS (70\% D2O)','SAXS + all SANS'};
naming_columns = {'dummy','$D_{12}$','$D_{13}$','$D_{23}$','$R_g$'};
filename_columns = {'dummy','D12','D13','D23','Rg'};

%%% figure settings
figure 
hold on
fontsize = 20;
set(gca,'box','on','fontsize',fontsize)
smooth_factor = 1; % smooth (1: no smoothing)
colors = {grey red black green blue yellow};
leg = 0;

for i = range
    color = colors{i};
    combi = combis{i};
    name = combi_names{i};
    theta = thetas{i};
    marker = '-';
    if strcmp(combi,'99') % only for initial distribution
        marker = '--'; 
        data = imp(['lambda_' lambda '/Distribution_combi_' combi '_column_' num2str(column) '.dat'],2,0);
    else
        data = imp(['lambda_' lambda '/Distribution_combi_' combi '_column_' num2str(column) '_theta_' theta '.dat'],2,0);
    end
    x = data{1};
    y = data{2};
    plot(x,smooth(y,smooth_factor),marker,'linewidth',linewidth,'color',color);
    leg = leg+1;
    legendinfo{leg} = name;
end

ylabel('Number of structures')
if column == 2
    xlabel('$D_{12}$ [\AA]')
elseif column == 3
    xlabel('$D_{13}$ [\AA]')
    axis([20 70 0 3000])
    letter = 'B';
    letter_x = 21;
    letter_y = 2860;
elseif column == 4
    xlabel('$D_{23}$ [\AA]')    
elseif column == 5
    %line([rg_exp rg_exp],ylim,'color',[0 0 0],'linewidth',linewidth)
    xlabel('$R_g$ [\AA]')
    axis([17 31 0 7000])
    letter = 'A';
    letter_x = 17.2;
    letter_y = 6620;
end

text(letter_x,letter_y,letter,'fontsize',fontsize)

%legendinfo{leg+1} = 'Experimental Rg';
if column == 5
    legend(legendinfo)
    set(legend,'interpreter','latex','fontsize',fontsize,'box','off','location','northeast')
end
if TITLE
    title([naming_columns{column} ' distribution, $\lambda$ = ' lambda]);
end
saveplot(['Compare_Distributions_lambda_' lambda '_' filename_columns{column} '.png'])
