program=run_BME_stage1.py
# j=0 for SAXS
# j=1 for SANS 0%
# j=2 for SANS 42%
# j=3 for SANS 70%
# j=4 for all
# j>4 for other combinations

for j in {1,2,3}
do
    echo "combination = $j"
    #for lambda in {1.00,1.01,1.02,1.03,1.04,1.05,1.052,1.054,1.055,1.056,1.058,1.06,1.07,1.08,1.09,1.10,1.20,1.50}
    for lambda in 1.08
    do
        echo " combi = $j,    lambda = $lambda"
        folder=theta_${lambda}/stage/.
        cp bme_reweight.py $program $folder
        cd $folder 
        /storage1/andreas/programs/anaconda2/bin/python2 $program $j 
        cd ../../
    done
done
