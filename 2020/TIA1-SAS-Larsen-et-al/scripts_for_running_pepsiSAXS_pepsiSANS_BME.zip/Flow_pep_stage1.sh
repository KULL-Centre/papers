program=run_pep_stage1_v2.py
#for lambda in {1.00,1.01,1.02,1.03,1.04,1.05,1.06,1.07,1.08,1.09,1.10,1.15,1.20,1.30,1.40,1.50}
for lambda in {1.00,1.04,1.06,1.08,1.10}
do
    folder=theta_$lambda/stage
    if [ ! -d "$folder" ]
    then
        if [ ! -d "theta_$lambda" ]
	then
            mkdir theta_$lambda
	fi
	mkdir $folder
    fi
    cp $program $folder
    cd $folder
    rm nohup.out
    nohup /storage1/andreas/programs/anaconda3/bin/python3 $program &
    cd ../../
done
