import os
import numpy as np

# skip last points (from SAXS dataset)
skip_last = 130 # for non-rebinned data

# user input
first_frame = 0
last_frame = 9999
nr_of_frames = last_frame-first_frame+1
print('nr_of_frames = %d\n' % nr_of_frames)

first_combination = 4
last_combination = 4

for combination in range(first_combination,last_combination+1):

    print('\nCombination %d initiated\n' % combination)
 
    if combination == 0:
        D = [-1]
    if combination == 1:
        D = [0]
    if combination == 2:
        D = [42]
    if combination == 3:
        D = [70]
    if combination == 4:
        D = [-1,0,42,70]
    if combination == 5:
        D = [-1,0]
    if combination == 6:
        D = [-1,42]
    if combination == 7:
        D = [-1,70]
    if combination == 8:
        D = [0,42]
    if combination == 9:
        D = [0,70]
    if combination == 10:
        D = [42,70]
    if combination == 11:
        D = [-1,0,42]     
    if combination == 12:
        D = [-1,0,70] 
    if combination == 13:
        D = [-1,42,70]
    if combination == 14:
        D = [0,42,70]

    # define names of files
    outfile_exp = 'exp_data_' + str(combination) + '.dat'
    outfile_calc = 'calc_data_' + str(combination) + '.dat'

    # print header to exp file
    with open(outfile_exp, 'w') as f:
        f.write("# DATA=SAXS PRIOR=GAUSS\n")

    # make first column of header to calc file
    header = "# label"

    for j in range(len(D)):
  
        #make EXP file
        footerlines = 0
        if D[j] == -1:
            #data_filename = "/lindorffgrp-isilon/andreas/prj_TIA1/Data/SASDCD3_Rebin.dat"
            data_filename = "/lindorffgrp-isilon/andreas/prj_TIA1/Data/SASDCD3.dat"
            headerlines = 0
        else:
            data_filename = "/lindorffgrp-isilon/andreas/prj_TIA1/Data/TIA-21-%d.dat" % D[j]
            headerlines = 1
        footerlines = 0
        q,Iexp,dI = np.genfromtxt(data_filename,skip_header=headerlines,skip_footer=footerlines,usecols=[0,1,2], unpack=True)
        if D[j] == -1:
            q = q[0:-skip_last]
            Iexp = Iexp[0:-skip_last]
            dI = dI[0:-skip_last]

        with open(outfile_exp, 'a') as f:
            for i in range(0,len(q)):
                f.write("%e \t %e \t %e \n" % (q[i],Iexp[i],dI[i]))

        # write CALC_FILE header
        for q_value in q:
            header += " \t %e" % q_value

    # print header to calc file
    header += " \n"
    with open(outfile_calc,'w') as f:
        f.write(header)

    # print rest of calc file
    for i in range(first_frame,last_frame+1):
        frame_number = i+1 # index with 1 instead of 0 for frame numbers
        frame_line = "frame_%d" % frame_number
        for j in range(len(D)):
            headerlines = 6
            footerlines = 0
            Ifit_col = 4
            if D[j] == -1:
                contrast = 0
                Ifit_col = 3
            elif D[j] == 0:
                contrast = 1
            elif D[j] == 42:
                contrast = 2
            elif D[j] == 70:
                contrast = 3
            fit_filename = "w_AA_frame%dchain_%d.fit" % (i,contrast)
            q,Iexp,dIexp,Ifit = np.genfromtxt(fit_filename,skip_header=headerlines,skip_footer=footerlines,usecols=[0,1,2,Ifit_col], unpack=True)
            for Ifit_value in Ifit:
                frame_line += " \t %e" % Ifit_value
        frame_line += '\n'  
        with open(outfile_calc,'a') as f:             
            f.write(frame_line)
    
    print('Combination %d out of %d done! \n' % (combination,last_combination))

print('\n Done with all combination! \n')

