#!/bin/sh
# 2019.03.19
# Yong
#for t in {1.01,1.02,1.03,1.04,1.05,1.06,1.07,1.08,1.09,1.10,1.20,1.50}
for t in {1.052,1.054,1.055,1.056,1.058}
do
    nohup ./Flow_Backmapping_lambda_xxx.sh $t &
done

