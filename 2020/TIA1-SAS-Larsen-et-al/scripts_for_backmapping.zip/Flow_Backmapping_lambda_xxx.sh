#!/bin/sh
# 2019.03.19
# Yong

source /lindorffgrp-isilon/wyong/software/GMX514/bin/GMXRC
gmx=/lindorffgrp-isilon/wyong/software/GMX514/bin/gmx_mpi_plumed241
BM=/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini3_seq2/test_backmapping/backward-v5/initram-v5_200.sh #backmapping program, fast version
AApdb=/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini3_seq2/TIA1_model2.pdb
FF=charmm27

t=${1?Error: no theta value given}
cd theta_$t
rm -r Backmapping
mkdir Backmapping
cd Backmapping
echo 1 | $gmx trjconv -f ../md2.xtc -o frame.pdb -pbc whole -skip 1 -sep -s ../md2.tpr -quiet #10,000 frames of 1 ns => 10,000 frames, no skipping
    
Nframe=`ls -1q frame*.pdb | wc -l`

$gmx pdb2gmx -f $AApdb -o AA.gro -ignh -water none -ff $FF -quiet

i=0
while [ $i -lt $Nframe ] 
do
    name=frame${i}
    CGgro=${name}.pdb
    echo $name
    bash $BM -f $CGgro -p topol.top -to charmm36 >/dev/null
    $gmx editconf -f backmapped.gro -o AA_${name}.pdb -quiet
    i=$(( $i + 1 ))
done

rm #*
rm backmapped.*
cd ../..
