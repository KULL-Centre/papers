
for lambda in {1.00,1.01,1.02,1.03,1.04,1.05,1.052,1.054,1.056,1.058,1.06,1.07,1.08,1.09,1.10,1.20,1.50}
do
    echo lambda = $lambda
    # move files
    cp average_block.py block.py README.block ../lambda_$lambda/.
    cd ../lambda_$lambda
    scp tyche:/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini30b417/lambda_sweep/theta_${lambda}/Distances/Dist_all.txt .

    #remove headerline from Dist.all and copy to Dist_all_clean.txt
    tail -n +2 Dist_all.txt > Dist_all_clean.txt

    # run block analysis
    bash README.block >> block.dat
    cd ../block_analysis
done
