
for lambda in {1.00,1.01,1.02,1.03,1.04,1.05,1.052,1.054,1.056,1.058,1.06,1.07,1.08,1.09,1.10,1.20,1.50}
do
    # copy summary 0 files
    echo lambda = $lambda
    cd ../lambda_$lambda
    scp tyche:/lindorffgrp-isilon/andreas/prj_TIA1/TIA1_Martini30b417/lambda_sweep/theta_${lambda}/stage/summary_0_file.dat .

    cd ../block_analysis
done