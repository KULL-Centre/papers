#!/usr/bin/env python

# see "Error estimates on averages of correlated data" by Flyvbjerg & Petersen, 1989

import numpy
from math import sqrt

class BlockTransform(object):
    """This class returns a stream of blocking transforms."""
    def __init__(self, data):
        def power2Q(n):                  # Function for clarity
            """Return True if unsigned int n is a power of 2."""
            return n & (n-1) == 0
        if not power2Q(len(data)):       # Say goodbye early
            raise ValueError, "length of data is not a power of 2."
        if len(data)<=2:
            raise ValueError, "Array is too small for block transforms."
        self.data = numpy.array(data)    # Explicit copy
	
    def __iter__(self):
        """This iterator yields the next block transform."""
        if len(self.data)<=2:
            raise ValueError, "No more block transforms to perform."
        yield self.data
        while len(self.data)>2:
            self.data = (self.data[::2]+self.data[1::2])/2.0
            yield self.data
        return
            
# define class BlockVariances
# use "object" as overall parent class (standard python class)
class BlockVariances(object): 
    """This class creates a sequence of variance estimates."""
    def __init__(self, data):
        self.nvs = list()
        for x in BlockTransform(data):
            #print " in blockvariance, x = ", len(x)
            n=len(x)
            v=x.var()/(n-1.0)
            s=v*sqrt(2.0/(n-1.0))
            #s=v*sqrt(2.0/(n+1.0))
            self.nvs.append((n, v, s))
            
    def __iter__(self):
        """This iterator yields the next block variance estimates."""
        for v in self.nvs:
            yield v
        return

def myNormal(m, s):
    # Correct for numpy's broken normal implementation.
    return numpy.random.normal(m,s) if s!=0 else m

#subclass to BlockVariances
class BlockSample(BlockVariances):
    """Variance Estimate from block sampling analysis"""
    def __init__(self, data):
        numpy.random.seed(123)
        super(BlockSample, self).__init__(data) # use the superclass BlockVariances' init method
        self.__mean = numpy.mean(numpy.array(data))

    def max_var(self):
        """Draw from the maximum of the variance distribution"""
        return max ( myNormal(x[1],x[2]) for x in self.nvs )

    def variance_sample(self, iterations=1000):
        return [self.max_var() for i in xrange(iterations)]

    def variance(self, iterations=1000):
        return numpy.mean( self.variance_sample(iterations) )

    def std_error(self, iterations=1000):
        return sqrt( self.variance(iterations) )

    def mean(self):
        return self.__mean

if __name__=="__main__":
    import sys
    f = open("data.txt",'r')
    a = list()
    for line in f:
        a.append(float(line.strip()))
    print "Length of a is: ", len(a) 
    b = BlockSample(numpy.array(a))
    print "The sample mean is: ", b.mean()
    print "The sample std error of the mean is: ", b.std_error()
    print "Here is a variance sample of 10,000 numbers: "
    #for v in b.variance_sample(10000):
    #    print v


    sys.exit()

