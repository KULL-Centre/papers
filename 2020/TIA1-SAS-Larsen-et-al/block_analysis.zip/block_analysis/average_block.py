#!/usr/bin/env python

import sys
import numpy
import block

if len(sys.argv)==1:
  sys.stdout.write("Usage:\n%s <file> [column=0]\n" % sys.argv[0])
  sys.exit()

if len(sys.argv)==2:
  file=open(sys.argv[1])
  col=0
if len(sys.argv)==3:
  file=open(sys.argv[1])
  col=int(sys.argv[2])

def power2_compatible(a):
  log2_len_a=numpy.log(len(a))/numpy.log(2)
  log2_len_sub_a=int(numpy.floor(log2_len_a))
  len_sub_a=2**log2_len_sub_a
  return len_sub_a,a[:len_sub_a],a[len(a)-len_sub_a:]


x=list()
for line in file.readlines():
  sl = line.split()
  if len(sl)>=col:
    x.append(float(sl[col]))
  else:
    print "Line",line,"does not have",col,"columns, exiting..."
    sys.exit(1)

x=numpy.array(x)

# calculate mean and SDOM without taking into account correlation
mean=x.mean()
var_bias=x.var()
var_unbias=var_bias*len(x)/(len(x)-1.0)
stddev=numpy.sqrt(var_unbias)
stderr=stddev/numpy.sqrt(len(x))

# make first and last set of power-2 compatible subsets of data
n,x_first,x_last=power2_compatible(x)

# make instance of class BlockSample
b_first=block.BlockSample(x_first)
# use instance method to calc std error
stderr_block_first=b_first.std_error()

# repeat for last (power-2 compatible) part
b_last=block.BlockSample(x_last)
stderr_block_last=b_last.std_error()

stderr_block=0.5*(stderr_block_first+stderr_block_last)
#print(stderr_block_first)
#print(stderr_block_last)
stderr_block_extrapolated=stderr_block*numpy.sqrt(float(n)/float(len(x)))

sys.stdout.write("    N: %d , Mean: %f , StdDev: %f , StdErr: %f , StdErrBlock: %f\n" % \
    (len(x),mean,stddev,stderr,stderr_block_extrapolated))

