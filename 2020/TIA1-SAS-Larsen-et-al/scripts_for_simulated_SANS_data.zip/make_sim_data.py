import os
import numpy as np

# user input
first_frame = 0
last_frame = 9999
nr_of_frames = last_frame-first_frame+1
first_combination = 0
last_combination = 3

for combi in range(first_combination,last_combination+1):

    print('Combination %d initiated\n' % combi)

    # define names of file
    outfile_sim = 'sim_data_' + str(combi) + '.dat'

    # make first column of header to sim file
    header = "# label"
  
    # get q-vector of calculated data
    if combi == 0:
        data_filename = "AA_frame0chain_saxs.fit"
    elif combi == 1:
        data_filename = "AA_frame0chain_deut69_d2o100_chainA.fit"  
    elif combi == 2:
        data_filename = "AA_frame0chain_deut69_d2o100_chainB.fit" 
    elif combi == 3:
        data_filename = "AA_frame0chain_deut69_d2o100_chainC.fit"
    footerlines = 0
    headerlines = 6
    q = np.genfromtxt(data_filename,skip_header=headerlines,skip_footer=footerlines,usecols=[0], unpack=True)

    # write SIM_FILE header
    for q_value in q:
        header += " \t %e" % q_value

    # print header to sim file
    header += " \n"
    with open(outfile_sim,'w') as f:
        f.write(header)

    # print rest of sim file
    for i in range(first_frame,nr_of_frames):
        frame_number = i+1 # index with 1 instead of 0 for frame numbers
        frame_line = "frame_%d" % frame_number
        if combi == 0:
            data_filename = "AA_frame%dchain_saxs.fit" % i
        elif combi == 1:
            data_filename = "AA_frame%dchain_deut69_d2o100_chainA.fit" % i
        elif combi == 2:
            data_filename = "AA_frame%dchain_deut69_d2o100_chainB.fit" % i
        elif combi == 3: 
            data_filename = "AA_frame%dchain_deut69_d2o100_chainC.fit" % i
        q,Isim = np.genfromtxt(data_filename,skip_header=headerlines,skip_footer=footerlines,usecols=[0,1], unpack=True)
        for I in Isim:
            frame_line += " \t %e" % I
        frame_line += '\n'  
        with open(outfile_sim,'a') as f:             
            f.write(frame_line)
    
    print('Combination %d out of %d done! \n' % (combi,last_combination))

print('Done with all simulated data! \n')
