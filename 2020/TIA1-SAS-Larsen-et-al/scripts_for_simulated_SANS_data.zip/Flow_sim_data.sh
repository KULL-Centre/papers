program=make_sim_data.py

for lambda in {1.04,1.06,1.08,1.10} 
#for lambda in 1.04 # for testing
do
    folder=theta_${lambda}/sim
    cp $program $folder
    cd $folder
    rm nohup
    nohup /storage1/andreas/programs/anaconda2/bin/python2 $program &
    cd ../..
done



