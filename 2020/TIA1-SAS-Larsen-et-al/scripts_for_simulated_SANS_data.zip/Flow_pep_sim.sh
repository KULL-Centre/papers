program=run_pep_sim.py
for lambda in {1.04,1.06,1.08,1.10}
#for lambda in 1.04 # for testing
do
    folder=theta_${lambda}/sim
    mkdir $folder
    cp $program $folder
    cd $folder
    nohup /storage1/andreas/programs/anaconda2/bin/python2 $program &
    cd ../..
done



