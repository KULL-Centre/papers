import subprocess
import os
import sys
import numpy as np

PepsiSANS_path = '/lindorffgrp-isilon/andreas/programs/Pepsi-SANS_linux_2.4 '
PepsiSAXS_path = '/lindorffgrp-isilon/andreas/programs/Pepsi-SAXS_linux_2.4 '

first_frame = 0
last_frame = 9999
nr_of_frames = last_frame - first_frame + 1

print('\n\n nr_of_frames (run_pep_simSANS.py)= %d' % nr_of_frames)
 
deut = '69'
chains = ['A','B','C']
for i in range(first_frame,last_frame+1):
    filename_short = "AA_frame%dchain" % i
    filename = '../chains/' + filename_short + '.pdb'
    for chain in chains:
        flags = ' --deuterated ' + chain + ' --deut 0.' + deut + ' --d2o 1.0 -o '
        outfilename = filename_short + '_deut' + deut + '_d2o100_chain' + chain + '.fit'
        command = PepsiSANS_path + filename + flags + outfilename
        os.system(command)
    outfilename = filename_short + '_saxs.fit'
    command = PepsiSAXS_path + filename + ' -o ' + outfilename
    os.system(command)

