import subprocess
import os
import sys
import numpy as np

first_frame = 0
last_frame = 9999
nr_of_frames = last_frame - first_frame +1
print('\n\n nr_of_frames = %d' % nr_of_frames)

# make chains for SANS calculation
last_atom_in_chain_A = 1418
last_atom_in_chain_B = 2840
for i in range(first_frame,last_frame+1):
    pdb_name_in = "../Backmapping/AA_frame%d.pdb" % i
    pdb_name_out = "AA_frame%dchain.pdb" % i
    pdb_out=open(pdb_name_out,"w")
    with open(pdb_name_in, 'r') as f:
        lines = f.readlines()
        for line in lines:
            if 'ATO' == line[0:3]:
                atomnumber = float(line[6:11])
                if atomnumber <= last_atom_in_chain_A:
                    string = line[0:21] + 'A' + line[22:]
                elif atomnumber <= last_atom_in_chain_B:
                    string = line[0:21] + 'B' + line[22:]
                else:
                    string = line[0:21] + 'C' + line[22:]
                pdb_out.write(string)
            else:
                pdb_out.write(line)
    pdb_out.close()

print('\n\n done making chains!')

