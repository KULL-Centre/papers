program=make_chains.py

for lambda in {1.00,1.04,1.06,1.08,1.10}
#for lambda in 1.00
do
  folder=theta_${lambda}/chains
  mkdir $folder
  cp $program $folder
  cd $folder
  nohup /storage1/andreas/programs/anaconda3/bin/python3 $program &
  cd ../..
done
