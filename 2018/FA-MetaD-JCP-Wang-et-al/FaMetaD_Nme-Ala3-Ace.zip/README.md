# FaMetaD Setting for Nme-Ala3-Ace
For further instructions see also:

https://plumed.github.io/doc-master/user-doc/html/_m_e_t_a_d.html

A typical example used for the paper's calculations is provided. 
It should allow the users make their own adjustments easily.

The used sofwares are:
 - PLUMED v2.5 
 - GROMACS 2015.4

# To run FaMetaD in GROMACS:

top=ala3.amber99sb-tip3p.top

gro=ala3_basinA.gro

export PLUMED_KERNEL=/home/people/wanyong/usr/local/PLUMED251/lib/libplumedKernel.so

export LD_LIBRARY_PATH=/home/people/wanyong/usr/local/PLUMED251/lib:$LD_LIBRARY_PATH

export PLUMED_USE_LEPTON=yes

gmx grompp -f md-implicit.mdp -c $gro -p $top -o md.tpr -maxwarn 2

mpirun -n 8 gmx mdrun -deffnm md -plumed plumed_FaMetaD.dat

