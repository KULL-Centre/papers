#!/bin/sh
#2019.04.25

top=ala3.amber99sb-tip3p.top
gro=ala3_basinA.gro

export PLUMED_KERNEL=/home/people/wanyong/usr/local/PLUMED251/lib/libplumedKernel.so
export PLUMED_USE_LEPTON=yes
export LD_LIBRARY_PATH=/home/people/wanyong/usr/local/PLUMED251/lib:$LD_LIBRARY_PATH

gmx grompp -f md-implicit.mdp -c $gro -p $top -o md.tpr -maxwarn 2

mpirun -n 8 gmx mdrun -deffnm md -plumed ../plumed_FaMetaD.dat

